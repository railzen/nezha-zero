const s="/assets/dashboard.BtVFv_j9.jpg",t="/assets/webssh.DHR7F3te.jpg";export{s as _,t as a};
