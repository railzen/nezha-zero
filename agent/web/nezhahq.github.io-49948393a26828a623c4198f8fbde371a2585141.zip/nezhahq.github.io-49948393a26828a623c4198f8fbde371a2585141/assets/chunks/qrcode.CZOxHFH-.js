const s="/assets/qrcode.b_bFVwtg.png";export{s as _};
